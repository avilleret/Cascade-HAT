

						This CAD library is for CadSoft - EAGLE tool


How to import new library file (.lbr) into EAGLE:

1. Download and extract the file.
2. Copy the library file (.lbr) to EAGLE library folder; "C:\Program Files\EAGLE-X.XX.X\lbr" (X.XX.X is your EAGLE software version)
3. Start EAGLE software.
4. Under EAGLE Control Panel, go to the Library tree and browse for new copied library (.lbr) file.
5. Right click on the library and select "USE".
6. You have successfully imported new library and ready to use in your design.  

Note: The library file is NOT compatible with versions prior to 6.0.

=============================================================================================================================================================

				For additional information, feedback and Technical support please contact reach from below:

Tech Support e-mail  ::	CAD_Tech@element14.com

----------------------------------------------------

Community website  

	http://www.element14.com/community/community/knode/cad_tools?view=overview

=============================================================================================================================================================

element14 Disclaimer :- 
 
This information has been provided to you free of charge for your use but remains the sole property of element14. While element14 has used reasonable efforts to ensure its accuracy, element14 does not guarantee that it is error-free, nor makes any warranty or guarantee as to the suitability of its schematics or footprints for any specific application. element14 reserves the right to make changes at any time without further notice. element14 expressly disclaims all implied warranties regarding this information, including but not limited to any implied warranties or merchantability or fitness for a particular purpose.
 
element14 will in no case be liable for your use, or the results of your use, of the CAD models or any accompanying written materials. It is your responsibility to verify the results of your use of this information in your own particular engineering and product environment and you assume the entire risk of doing so or failing to do so. 
 
Footprint designs were developed using standard layout guidelines for most common and practical applications. All schematic symbols, footprints and layer definitions should be validated by the customer�s own technical experts as application specific requirements may differ.
