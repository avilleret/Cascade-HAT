

						This CAD library is for CadSoft - EAGLE tool

To import your new library into EAGLE:

1. Start EAGLE.
2. Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Script from the menu.
4. Select the EDIT tab.
5. Browse to the correct EAGLE Script file (".scr" file extension) in the file "Open" window.
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in EAGLE native format.

=============================================================================================================================================================

				For additional information, feedback and Technical support please contact reach from below:

Tech Support e-mail  ::	CAD_Tech@element14.com

----------------------------------------------------

Community website  

	http://www.element14.com/community/community/knode/cad_tools?view=overview

-----------------------------------------------------
Newark -USA 

	http://www.newark.com/jsp/bespoke/bespoke2.jsp?bespokepage=newark/en_US/custsrv/index.jsp

-----------------------------------------------------
element14(Farnell) -Europe 

 	http://grh.premierfarnell.com/pageredir.aspx?c=EU1&u=jsp/content/freetoair.jsp?content=contact
	www.farnell.com/livechat

-----------------------------------------------------
element14(Farnell) -ASIA

	http://grh.premierfarnell.com/pageredir.aspx?c=AP&u=jsp/bespoke/bespoke2.jsp?bespokepage=e14/en_IN/custsrv/index.jsp
	www.farnell.com/livechat

=============================================================================================================================================================

element14 Disclaimer :- 
 
This information has been provided to you free of charge for your use but remains the sole property of element14. While element14 has used reasonable efforts to ensure its accuracy, element14 does not guarantee that it is error-free, nor makes any warranty or guarantee as to the suitability of its schematics or footprints for any specific application. element14 reserves the right to make changes at any time without further notice. element14 expressly disclaims all implied warranties regarding this information, including but not limited to any implied warranties or merchantability or fitness for a particular purpose.
 
element14 will in no case be liable for your use, or the results of your use, of the CAD models or any accompanying written materials. It is your responsibility to verify the results of your use of this information in your own particular engineering and product environment and you assume the entire risk of doing so or failing to do so. 
 
Footprint designs were developed using standard layout guidelines for most common and practical applications. All schematic symbols, footprints and layer definitions should be validated by the customer�s own technical experts as application specific requirements may differ.
